package env;
public class ApplicationProperties {
	public static String URL = "http://localhost:4000";
}
