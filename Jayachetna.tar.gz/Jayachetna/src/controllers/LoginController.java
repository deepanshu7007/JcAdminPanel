package controllers;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonSerializer;

import entity.User;
import env.ApplicationProperties;

public class LoginController {
	public User isLoggedIn(String route, String email, String password) {
		try {
			// Create a URL object with the target URL
			URL url = new URL(ApplicationProperties.URL + route);
			System.out.println(ApplicationProperties.URL + route);
			// Open a connection to the URL
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();

			// Set the request method to POST
			connection.setRequestMethod("POST");

			// Set the content type
			connection.setRequestProperty("Content-Type", "application/json");

			// Enable input/output streams for sending data
			connection.setDoOutput(true);

			// Data to be sent in the request body
			String data = "{\"email\": \"" + email + "\", \"password\": \"" + password + "\"}";

			// Write data to the output stream
			OutputStream os = connection.getOutputStream();
			OutputStreamWriter writer = new OutputStreamWriter(os);
			writer.write(data);
			writer.flush();
			writer.close();
			os.close();

			// Get the response code
			int responseCode = connection.getResponseCode();
			@SuppressWarnings("unused")
			String responseMessage = connection.getResponseMessage();

			System.out.println("Response Code: " + responseCode);

			if (responseCode == HttpURLConnection.HTTP_OK) {
				System.err.println("Response Message:" + connection);
				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String inputLine;
				StringBuilder response = new StringBuilder();
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				System.out.println("Response Data: " + response.toString());
			    Gson g = new Gson();  
			    JSONObject obj = new JSONObject(response.toString());
			    User user = g.fromJson(obj.get("data").toString(), User.class);
			    System.err.println(user);
			    
				return user;
			} else {
				System.out.println("POST request failed");
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
}
