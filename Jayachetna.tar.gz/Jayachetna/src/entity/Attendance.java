package entity;

public class Attendance {
	
}
