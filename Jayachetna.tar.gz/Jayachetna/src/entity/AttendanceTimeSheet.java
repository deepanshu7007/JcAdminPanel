package entity;

public class AttendanceTimeSheet {
	private String date; //refers to current time
	private String totalTime; 
	private String totalSeconds;
	private String status;
	private Boolean isDeleted;
	private User deletedBy; //referes to the user who deleted
	private String deletedAt; //refers to the datetime in which it is deleted
	private String updatedBy;
	private String addedBy;
	private String createdAt;
	private String updatedAt;
	private String checkInDevice;
	private String checkOutDevice;
	private String mobileDeviceTime;
	private String desktopDeviceTime;
}
