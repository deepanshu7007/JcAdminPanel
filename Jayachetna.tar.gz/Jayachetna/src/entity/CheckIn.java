package entity;

public class CheckIn {
	private String createdAt;
	private String updatedAt;
	private String id;
	private String checkIn;
	private String checkOut;
	private String name;
	private String email;
	private String totalTime;
	private String totalseconds;
	private String attendanceDate;
	private String punchInDate;
	private String reason;
	private String status;
	private String isDeleted;
	private String deletedAt;
	private String check_in_device;
	private String check_out_device;
	private String userId;
	private String deletedBy;
	private String updatedBy;
	private String addedBy;
	private String success;
	private String message;
	private boolean alreadyCheckedIn;
	private String lastCheckInTime;
	private String checkInId;
	
	public boolean getAlreadyCheckedIn() {
		return alreadyCheckedIn;
	}

	public void setAlreadyCheckedIn(boolean alreadyCheckedIn) {
		this.alreadyCheckedIn = alreadyCheckedIn;
	}

	public String getLastCheckInTime() {
		return lastCheckInTime;
	}

	public void setLastCheckInTime(String lastCheckInTime) {
		this.lastCheckInTime = lastCheckInTime;
	}

	public String getCheckInId() {
		return checkInId;
	}

	public void setCheckInId(String checkInId) {
		this.checkInId = checkInId;
	}

	public String getSuccess() {
		return success;
	}

	public void setSuccess(String success) {
		this.success = success;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "CheckIn [createdAt=" + createdAt + ", updatedAt=" + updatedAt + ", id=" + id + ", checkIn=" + checkIn
				+ ", checkOut=" + checkOut + ", name=" + name + ", email=" + email + ", totalTime=" + totalTime
				+ ", totalseconds=" + totalseconds + ", attendanceDate=" + attendanceDate + ", punchInDate="
				+ punchInDate + ", reason=" + reason + ", status=" + status + ", isDeleted=" + isDeleted
				+ ", deletedAt=" + deletedAt + ", check_in_device=" + check_in_device + ", check_out_device="
				+ check_out_device + ", userId=" + userId + ", deletedBy=" + deletedBy + ", updatedBy=" + updatedBy
				+ ", addedBy=" + addedBy + "]";
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCheckIn() {
		return checkIn;
	}

	public void setCheckIn(String checkIn) {
		this.checkIn = checkIn;
	}

	public String getCheckOut() {
		return checkOut;
	}

	public void setCheckOut(String checkOut) {
		this.checkOut = checkOut;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTotalTime() {
		return totalTime;
	}

	public void setTotalTime(String totalTime) {
		this.totalTime = totalTime;
	}

	public String getTotalseconds() {
		return totalseconds;
	}

	public void setTotalseconds(String totalseconds) {
		this.totalseconds = totalseconds;
	}

	public String getAttendanceDate() {
		return attendanceDate;
	}

	public void setAttendanceDate(String attendanceDate) {
		this.attendanceDate = attendanceDate;
	}

	public String getPunchInDate() {
		return punchInDate;
	}

	public void setPunchInDate(String punchInDate) {
		this.punchInDate = punchInDate;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getDeletedAt() {
		return deletedAt;
	}

	public void setDeletedAt(String deletedAt) {
		this.deletedAt = deletedAt;
	}

	public String getCheck_in_device() {
		return check_in_device;
	}

	public void setCheck_in_device(String check_in_device) {
		this.check_in_device = check_in_device;
	}

	public String getCheck_out_device() {
		return check_out_device;
	}

	public void setCheck_out_device(String check_out_device) {
		this.check_out_device = check_out_device;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDeletedBy() {
		return deletedBy;
	}

	public void setDeletedBy(String deletedBy) {
		this.deletedBy = deletedBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}
}
