package entity;

public class CheckOut {
	private String success;
	private String message;
	private String checkInTime;
	private String checkOutTime;
	private String name;
	private String email;
	private String totalTime;
	private String totalSeconds;
	private String attendanceDate;
	private String punchInDate;
	private String reason;
	private String status;
	private String isDeleted;
	private String deletedAt;
	private String checkInDevice;
	private String checkOutDevice;
	private String userId;
	private String deletedBy;
	private String updatedBy;
	private String addedBy;
	@Override
	public String toString() {
		return "CheckOut [success=" + success + ", message=" + message + ", checkInTime=" + checkInTime
				+ ", checkOutTime=" + checkOutTime + ", name=" + name + ", email=" + email + ", totalTime=" + totalTime
				+ ", totalSeconds=" + totalSeconds + ", attendanceDate=" + attendanceDate + ", punchInDate="
				+ punchInDate + ", reason=" + reason + ", status=" + status + ", isDeleted=" + isDeleted
				+ ", deletedAt=" + deletedAt + ", checkInDevice=" + checkInDevice + ", checkOutDevice=" + checkOutDevice
				+ ", userId=" + userId + ", deletedBy=" + deletedBy + ", updatedBy=" + updatedBy + ", addedBy="
				+ addedBy + "]";
	}
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCheckInTime() {
		return checkInTime;
	}
	public void setCheckInTime(String checkInTime) {
		this.checkInTime = checkInTime;
	}
	public String getCheckOutTime() {
		return checkOutTime;
	}
	public void setCheckOutTime(String checkOutTime) {
		this.checkOutTime = checkOutTime;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTotalTime() {
		return totalTime;
	}
	public void setTotalTime(String totalTime) {
		this.totalTime = totalTime;
	}
	public String getTotalSeconds() {
		return totalSeconds;
	}
	public void setTotalSeconds(String totalSeconds) {
		this.totalSeconds = totalSeconds;
	}
	public String getAttendanceDate() {
		return attendanceDate;
	}
	public void setAttendanceDate(String attendanceDate) {
		this.attendanceDate = attendanceDate;
	}
	public String getPunchInDate() {
		return punchInDate;
	}
	public void setPunchInDate(String punchInDate) {
		this.punchInDate = punchInDate;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}
	public String getDeletedAt() {
		return deletedAt;
	}
	public void setDeletedAt(String deletedAt) {
		this.deletedAt = deletedAt;
	}
	public String getCheckInDevice() {
		return checkInDevice;
	}
	public void setCheckInDevice(String checkInDevice) {
		this.checkInDevice = checkInDevice;
	}
	public String getCheckOutDevice() {
		return checkOutDevice;
	}
	public void setCheckOutDevice(String checkOutDevice) {
		this.checkOutDevice = checkOutDevice;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(String deletedBy) {
		this.deletedBy = deletedBy;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getAddedBy() {
		return addedBy;
	}
	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}
}
