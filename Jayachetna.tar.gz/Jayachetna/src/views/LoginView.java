package views;
import javax.swing.*;

import controllers.DashboardController;
import controllers.LoginController;
import entity.User;

import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
@SuppressWarnings("serial")
public class LoginView extends JFrame{
	public LoginView() {
		setBackground(new Color(238, 238, 236));
	}
	User user;
	private static JTextField emailField;
	private static JPasswordField passwordField;
     {
        setTitle("Jc Software Solutions");
        setSize(733, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(238, 238, 236));
        getContentPane().add(panel_1, BorderLayout.CENTER);
        panel_1.setLayout(new BorderLayout(0, 0));

        JPanel panel_2 = new JPanel();
        panel_2.setBackground(new Color(255, 255, 255));
        panel_1.add(panel_2, BorderLayout.CENTER);
        GridBagLayout gbl_panel_2 = new GridBagLayout();
        gbl_panel_2.columnWidths = new int[]{328, 186, 78, 0, 0};
        gbl_panel_2.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
        gbl_panel_2.columnWeights = new double[]{1.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
        gbl_panel_2.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
        panel_2.setLayout(gbl_panel_2);
        
        JLabel titleLabel_1 = new JLabel("");
        titleLabel_1.setIcon(new ImageIcon("/home/jc22/Pictures/JCLogo.png"));
        titleLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel_1.setFont(new Font("Dialog", Font.BOLD, 23));
        GridBagConstraints gbc_titleLabel_1 = new GridBagConstraints();
        gbc_titleLabel_1.fill = GridBagConstraints.HORIZONTAL;
        gbc_titleLabel_1.gridwidth = 2;
        gbc_titleLabel_1.insets = new Insets(0, 0, 5, 5);
        gbc_titleLabel_1.gridx = 1;
        gbc_titleLabel_1.gridy = 0;
        panel_2.add(titleLabel_1, gbc_titleLabel_1);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon("/home/jc22/Pictures/Screenshot from 2023-11-01 16-17-11.png"));
        GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
        gbc_lblNewLabel.gridheight = 7;
        gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
        gbc_lblNewLabel.gridx = 0;
        gbc_lblNewLabel.gridy = 1;
        panel_2.add(lblNewLabel, gbc_lblNewLabel);
        
        JLabel titleLabel = new JLabel("Login");
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setForeground(new Color(252, 175, 62));
        titleLabel.setFont(new Font("Dialog", Font.BOLD, 23));
        GridBagConstraints gbc_titleLabel = new GridBagConstraints();
        gbc_titleLabel.gridwidth = 2;
        gbc_titleLabel.insets = new Insets(0, 0, 5, 5);
        gbc_titleLabel.gridx = 1;
        gbc_titleLabel.gridy = 1;
        panel_2.add(titleLabel, gbc_titleLabel);
        
        JLabel emailLabel = new JLabel("Email");
        emailLabel.setFont(new Font("Dialog", Font.PLAIN, 18));
        emailLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        GridBagConstraints gbc_emailLabel = new GridBagConstraints();
        gbc_emailLabel.anchor = GridBagConstraints.WEST;
        gbc_emailLabel.insets = new Insets(0, 0, 5, 5);
        gbc_emailLabel.gridx = 1;
        gbc_emailLabel.gridy = 3;
        panel_2.add(emailLabel, gbc_emailLabel);
        
        emailField = new JTextField();
        emailField.setFont(new Font("Dialog", Font.PLAIN, 18));
        GridBagConstraints gbc_emailField = new GridBagConstraints();
        gbc_emailField.gridwidth = 2;
        gbc_emailField.insets = new Insets(0, 0, 5, 5);
        gbc_emailField.fill = GridBagConstraints.HORIZONTAL;
        gbc_emailField.gridx = 1;
        gbc_emailField.gridy = 4;
        panel_2.add(emailField, gbc_emailField);
        emailField.setColumns(10);
        
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(new Font("Dialog", Font.PLAIN, 18));
        GridBagConstraints gbc_passwordLabel = new GridBagConstraints();
        gbc_passwordLabel.fill = GridBagConstraints.HORIZONTAL;
        gbc_passwordLabel.insets = new Insets(0, 0, 5, 5);
        gbc_passwordLabel.gridx = 1;
        gbc_passwordLabel.gridy = 5;
        panel_2.add(passwordLabel, gbc_passwordLabel);
        
        passwordField = new JPasswordField();
        passwordField.setFont(new Font("DejaVu Sans", Font.PLAIN, 18));
        GridBagConstraints gbc_passwordField = new GridBagConstraints();
        gbc_passwordField.gridwidth = 2;
        gbc_passwordField.insets = new Insets(0, 0, 5, 5);
        gbc_passwordField.fill = GridBagConstraints.HORIZONTAL;
        gbc_passwordField.gridx = 1;
        gbc_passwordField.gridy = 6;
        panel_2.add(passwordField, gbc_passwordField);
        
        JButton loginBtn = new JButton("LOGIN");
        loginBtn.setBackground(new Color(252, 175, 62));
        
        loginBtn.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        		SwingWorker<String, Void> worker = new SwingWorker<String, Void>() {
                    @SuppressWarnings("deprecation")
					@Override
                    protected String doInBackground() throws Exception {
                        // Perform the data retrieval here
                    	user = new LoginController().isLoggedIn("/user/signin", emailField.getText(), passwordField.getText());
                    	System.out.println("Visited here");
                    	return "true";
                    }

                    @Override
                    protected void done() {
                        try {
                            // Update the Swing components on the EDT
                        	if(user!=null) {
                    			DashboardController dc = new DashboardController(user.getAccess_token(),user.getCheckInStatus(),user.getFullName());
                    			System.out.println(user.getBearerToken());
                    			setVisible(false);
                        	}
                        	else
                    		{
                    			JOptionPane.showInternalMessageDialog(null, "Something went wrong either email/password not correct or something wrong with connection to host");
                    		}
                        } catch (Exception ex) {
                            ex.printStackTrace();
                           
                        }
                    }
                };
                worker.execute();
        	}
        });
        loginBtn.setFont(new Font("DejaVu Sans", Font.PLAIN, 16));
        GridBagConstraints gbc_loginBtn = new GridBagConstraints();
        gbc_loginBtn.anchor = GridBagConstraints.EAST;
        gbc_loginBtn.insets = new Insets(0, 0, 5, 5);
        gbc_loginBtn.gridx = 1;
        gbc_loginBtn.gridy = 7;
        panel_2.add(loginBtn, gbc_loginBtn);
        
        JButton cancelBtn = new JButton("CANCEL");
        cancelBtn.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		System.exit(1);
        	}
        });
        cancelBtn.setFont(new Font("DejaVu Sans", Font.PLAIN, 16));
        GridBagConstraints gbc_cancelBtn = new GridBagConstraints();
        gbc_cancelBtn.anchor = GridBagConstraints.WEST;
        gbc_cancelBtn.insets = new Insets(0, 0, 5, 5);
        gbc_cancelBtn.gridx = 2;
        gbc_cancelBtn.gridy = 7;
        panel_2.add(cancelBtn, gbc_cancelBtn);
        setVisible(true);
        
    }
}