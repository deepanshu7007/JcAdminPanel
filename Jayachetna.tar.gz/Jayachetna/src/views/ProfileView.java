package views;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JLayeredPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JFormattedTextField;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.ListSelectionModel;

public class ProfileView extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProfileView frame = new ProfileView("ANY NAME");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ProfileView(String fullName) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 550);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(tabbedPane, BorderLayout.CENTER);
		
		JLayeredPane layeredPane = new JLayeredPane();
		tabbedPane.addTab("Dashboard", null, layeredPane, null);
		
		JLayeredPane layeredPane_1 = new JLayeredPane();
		tabbedPane.addTab("Attendance", null, layeredPane_1, null);
		GridBagLayout gbl_layeredPane_1 = new GridBagLayout();
		gbl_layeredPane_1.columnWidths = new int[]{0, 235, 0, 0, 0};
		gbl_layeredPane_1.rowHeights = new int[]{0, 0, 0, 0, 0};
		gbl_layeredPane_1.columnWeights = new double[]{1.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_layeredPane_1.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		layeredPane_1.setLayout(gbl_layeredPane_1);
		
		JLabel lblDeepanshuChoudhary = new JLabel(fullName);
		lblDeepanshuChoudhary.setFont(new Font("DejaVu Sans", Font.PLAIN, 20));
		GridBagConstraints gbc_lblDeepanshuChoudhary = new GridBagConstraints();
		gbc_lblDeepanshuChoudhary.gridwidth = 2;
		gbc_lblDeepanshuChoudhary.anchor = GridBagConstraints.EAST;
		gbc_lblDeepanshuChoudhary.insets = new Insets(0, 0, 5, 0);
		gbc_lblDeepanshuChoudhary.gridx = 2;
		gbc_lblDeepanshuChoudhary.gridy = 0;
		layeredPane_1.add(lblDeepanshuChoudhary, gbc_lblDeepanshuChoudhary);
		
		JLabel lblAttendance = new JLabel("Attendance");
		lblAttendance.setFont(new Font("DejaVu Sans", Font.PLAIN, 21));
		GridBagConstraints gbc_lblAttendance = new GridBagConstraints();
		gbc_lblAttendance.anchor = GridBagConstraints.WEST;
		gbc_lblAttendance.gridwidth = 2;
		gbc_lblAttendance.insets = new Insets(0, 0, 5, 5);
		gbc_lblAttendance.gridx = 0;
		gbc_lblAttendance.gridy = 1;
		layeredPane_1.add(lblAttendance, gbc_lblAttendance);
		
		JLabel lblNewLabel = new JLabel("Please Punchout Before Leave");
		lblNewLabel.setFont(new Font("DejaVu Sans", Font.PLAIN, 20));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.gridwidth = 2;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel.gridx = 2;
		gbc_lblNewLabel.gridy = 1;
		layeredPane_1.add(lblNewLabel, gbc_lblNewLabel);
		
		JButton btnNewButton = new JButton("Punchout");
		btnNewButton.setForeground(new Color(238, 238, 236));
		btnNewButton.setBackground(new Color(239, 41, 41));
		btnNewButton.setFont(new Font("DejaVu Sans", Font.PLAIN, 21));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.fill = GridBagConstraints.VERTICAL;
		gbc_btnNewButton.anchor = GridBagConstraints.WEST;
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 5);
		gbc_btnNewButton.gridx = 0;
		gbc_btnNewButton.gridy = 2;
		layeredPane_1.add(btnNewButton, gbc_btnNewButton);
		
		JFormattedTextField formattedTextField = new JFormattedTextField();
		formattedTextField.setFont(new Font("DejaVu Sans", Font.PLAIN, 16));
		formattedTextField.setHorizontalAlignment(SwingConstants.RIGHT);
		GridBagConstraints gbc_formattedTextField = new GridBagConstraints();
		gbc_formattedTextField.insets = new Insets(0, 0, 5, 5);
		gbc_formattedTextField.fill = GridBagConstraints.BOTH;
		gbc_formattedTextField.gridx = 2;
		gbc_formattedTextField.gridy = 2;
		layeredPane_1.add(formattedTextField, gbc_formattedTextField);
		
		JButton btnNewButton_1 = new JButton("CLEAR");
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.fill = GridBagConstraints.VERTICAL;
		gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 0);
		gbc_btnNewButton_1.gridx = 3;
		gbc_btnNewButton_1.gridy = 2;
		layeredPane_1.add(btnNewButton_1, gbc_btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.gridwidth = 4;
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 3;
		layeredPane_1.add(scrollPane, gbc_scrollPane);
		
		JTable table = new JTable(3,3);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setFont(new Font("DejaVu Sans", Font.PLAIN, 22));
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
			},
			new String[] {
				"DATE","PUNCHIN-TIME", "PUNCHOUT-TIME", "REASON","TIME"
			}
		));
		table.setShowVerticalLines(true);
		table.setShowHorizontalLines(true);
		scrollPane.setViewportView(table);
		
		JLayeredPane layeredPane_2 = new JLayeredPane();
		tabbedPane.addTab("Assigned Projects", null, layeredPane_2, null);
		
		JLayeredPane layeredPane_2_1 = new JLayeredPane();
		tabbedPane.addTab("Knowledge Sharing", null, layeredPane_2_1, null);
		
		JLayeredPane layeredPane_2_1_1 = new JLayeredPane();
		tabbedPane.addTab("Leave", null, layeredPane_2_1_1, null);
		
		JLayeredPane layeredPane_2_1_2 = new JLayeredPane();
		tabbedPane.addTab("Resignation", null, layeredPane_2_1_2, null);
		
		JLayeredPane layeredPane_2_1_2_1 = new JLayeredPane();
		tabbedPane.addTab("Review Projects", null, layeredPane_2_1_2_1, null);
		setVisible(true);
	}
}
